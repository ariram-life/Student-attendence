# Student Attendance Android App

## Build APK on GitHub Actions
1. Create a GitHub repository named `StudentAttendance`.
2. Upload the **contents** of this folder (including `.github`) to the repository root.
3. Open the repository's **Actions** tab. The workflow `Build Student Attendance APK` starts after the first push. If needed, choose it and tap **Run workflow**.
4. When the run finishes, open it and download the artifact named `student-attendance-debug-apk`.
5. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone. Allow installation from your browser/files app if Android asks.

This is a debug APK for personal testing, not a Play Store release build.
